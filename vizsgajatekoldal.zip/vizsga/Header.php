<?php
session_start();
require("kapcs.inc.php");
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Webshop</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">

    
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>

     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   
</head>
<body>

<header class="p-3 mb-3 border-bottom">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-dark text-decoration-none">
          <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"></use></svg>
          
        </a>

        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a href="Index.php" class="nav-link px-2 link-secondary">Főoldal</a></li>
          <li><a href="#" class="nav-link px-2 link-dark">Akciós</a></li>
          <li><a href="#" class="nav-link px-2 link-dark">Customers</a></li>
          <li><a href="#" class="nav-link px-2 link-dark">Products</a></li>
        </ul>

        <form class="d-flex">
          <input type="search" name="keywords" class="form-control me-2" placeholder="Keresés..." href="index.php" aria-label="Search">
         
        </form>
        <?php
       


        if(!isset($_SESSION['nev']))
        {
            print(" <div class='dropdown text-end'>
            <a href='#' class='d-block link-dark text-decoration-none dropdown-toggle' id='dropdownUser1' data-bs-toggle='dropdown' aria-expanded='false'>
            Belépés
            </a>
            <ul class='dropdown-menu text-small' aria-labelledby='dropdownUser1'>
              <li><a class='dropdown-item' href='Bejelentkezescssel.php'>Bejelentkezés</a></li>
              <li><hr class='dropdown-divider'></li>
              <li><a class='dropdown-item' href='regisztraciocssel.php'>Regisztráció</a></li>
              
              
            </ul>
          </div>");
        }
        else
        {
            $egyenleg = "SELECT egyenleg FROM vevo WHERE nev ='".$_SESSION['nev']."';";
            $_SESSION['egyenleg'] = $egyenleg;
            $admin = mysqli_query($con,"SELECT admin FROM vevo WHERE nev ='".$_SESSION['nev']."'") or die;
            $rekord = mysqli_fetch_object($admin);
            $profilkep = mysqli_query($con,"SELECT profilkepek FROM vevo WHERE nev ='".$_SESSION['nev']."'") or die ("Nem sikerült a lekérdezés!");
            $prekord = mysqli_fetch_object($profilkep);

            print("<a href='Egyenleg.php' class='nav-link px-2 link-dark'>Egyenleged: "); $eredmeny = $con->query($egyenleg);
                                            while($row = $eredmeny->fetch_assoc())
                                            {
                                                echo $row['egyenleg'] , "Ft &nbsp&nbsp";
                                            } print("</a>");

            print(" <div class='dropdown text-end'>
            <a href='#' class='d-block link-dark text-decoration-none dropdown-toggle' id='dropdownUser1' data-bs-toggle='dropdown' aria-expanded='false'>
            <img src='$prekord->profilkepek ' alt='Profil Képed' width='32' height='32' class='rounded-circle'>
            </a>
            <ul class='dropdown-menu text-small' aria-labelledby='dropdownUser1'>
              <li><a class='dropdown-item' href='Profil.php'>Profil</a></li>
              <li><a class='dropdown-item' href='Egyenleg.php'>Egyenleg</a></li>");
              if($rekord->admin == 1)
              {
              print("<li><a class='dropdown-item' href='Felhasznalok.php'>Felhasználók</a></li>
                    <li><a class='dropdown-item' href='Termekfeltoltes.php'>Termékfeltöltés</a></li>");
              }
              print("<li><hr class='dropdown-divider'></li>
              <li><a class='dropdown-item' href='Kijelentkezes.php'>Kijelentkezés</a></li>
              
              
            </ul>
          </div>");

          //
            // print("<button class='legordulogomb'>".$_SESSION['nev']." "."<img id='profilkep' src='$prekord->profilkepek '></button>");
            // print("<a href='Egyenleg.php'>Egyenleg</a>");
            // print("<a href='#'>Játékaid</a>");
            // print("<a href='teszt.php'>jatekok</a>");
            // if($rekord->admin == 1){
            //     print("<a href='Felhasznalok.php'>Felhasználók</a>");
            //     print("<a href='Termekfeltoltes.php'>Termékfeltöltés</a>");
            // }
            // print("<a href='Kijelentkezes.php'>Kijelentkezés</a>");
            // print("</div>");
        }
      ?>
       
      </div>
    </div>
  </header>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/popper.min.js"></script>

</body>
</html>
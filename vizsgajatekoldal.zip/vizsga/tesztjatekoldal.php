<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Webshop</title>
    <link rel="stylesheet" href="vizsga/css/bootstrap.min.css">


</head>
<body>
    Sikeres
    <?php

    require("kapcs.inc.php");

    $termekid = mysqli_query($con,"SELECT * FROM termek WHERE termekid='".$_GET['m']."';") or die ("Nem sikerült a lekérdezés!");
    $KivalasztottOldal = $_GET['m'];
    if($termekid->num_rows>0){
    while($row = $termekid->fetch_assoc()){
        $nev = $row["nev"];
        $ar  = $row["ar"];
        $mufaj = $row["mufaj"];
        $lerias = $row["lerias"];
        $kep = $row["kep"];
        ?>

        <?php
    }}
    
    ?>

                                   
   

</body>
</html>
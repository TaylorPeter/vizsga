<?php

include "header.php";

if(!isset($_POST['gomb'])){
print("<form action='Egyenleg.php' method='post'><br>");
print("<p style='margin-left: 15px;'>Összeg: <input type='number' name='egyenleg'>");
print("<br><p><input style='margin-left: 15px;' type='submit' class='btn btn-primary' name='gomb' value='Feltöltés'><br>");
print("</form>");

}
else
{
    require("kapcs.inc.php");

    $egyenleg = $_POST['egyenleg'];
    
    
    
    $eredmeny = $con->query($_SESSION['egyenleg']);
        while($row = $eredmeny->fetch_assoc())
                                {
                                 $_SESSION['egyenleg'] = $row['egyenleg'];
                                 $ossz = ($egyenleg + $_SESSION['egyenleg']);
                                }

                                

    $query = "UPDATE vevo SET egyenleg=$ossz WHERE nev ='".$_SESSION['nev']."';";
                mysqli_query($con,$query) or die ('Hiba az adatbevitelnél!');
                print("<script>alert('Sikeres feltöltés!'); window.location.href = 'index.php';</script>");
}

?>
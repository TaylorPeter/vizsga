<?php

    require("kapcs.inc.php");
    $nev5 = $_GET['q'];
    $querrry = "SELECT * FROM vevo";
    $a = 0;


    $results8 = mysqli_query($con, $querrry);
    while($rekord10=mysqli_fetch_object($results8))
    {
     
        if ($rekord10->nev == $nev5){
        $emlek = $rekord10->emlek;
        $a = 1;
     
        }
        else
        {
            if($a==0){
               $emlek="Nincs jelszó emlékeztető.";
            }
            
        }
    }

    if($emlek == ""){
        $emlek="Nincs jelszó emlékeztető.";
    }
    
 print("Jelszó emlékeztető: ".$emlek);
    


?>

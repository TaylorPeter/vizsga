<?php
require "kapcs.inc.php";
           $kosarid = $_GET['t'];
           $query7 = "DELETE FROM kosar WHERE kosarid = $kosarid";
           mysqli_query($con,$query7) or die ('Hiba az adatbevitelnél!');
           print("<meta http-equiv='refresh' content='0'> ");
           if (isset($_SERVER["HTTP_REFERER"])) {
            header("Location: " . $_SERVER["HTTP_REFERER"]);
            }

?>
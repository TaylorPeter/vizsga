<?php
            require ("Header.php");
            use PHPMailer\PHPMailer\PHPMailer;

            $nev = $_SESSION['nev'];
            $query13 = "SELECT SUM(ar) FROM kosar WHERE vevoid = '".$_SESSION['vevoid']."';";

            $osszegar = mysqli_query($con,$query13) or die ('Hiba az adatbevitelnél!');
            $osszegar2 = mysqli_fetch_array($osszegar);
            $vegosszeg = $osszegar2[0];
  
if($vegosszeg > $_SESSION['egyenleg2']){
    ?>
    <script>alert("Nincs elég pénzed!");
     
     window.location.href='index.php';</script><?php
}
else{      
        

            require("kapcs.inc.php");
            $req ="SELECT * FROM vevo";
            $results = mysqli_query($con,$req) or die("Sikertelen frissítés");
            while($rekord=mysqli_fetch_object($results))
            {
                if ($rekord->nev == $nev){
                $email = $rekord->email;
                
                }
            }
            $jatekneve = mysqli_query($con, "SELECT  * FROM kosar WHERE vevoid = '".$_SESSION['vevoid']."';") or die ("Nem sikerült a lekérdezés!");

            



function VerificationSend($email2,$nev2,$jatekneve){

    require_once "PHPMailer/PHPMailer.php";
    require_once "PHPMailer/SMTP.php";
    require_once "PHPMailer/Exception.php";

    $mail = new PHPMailer();

    //SMTP Settings
    $mail->isSMTP();
    $jelszo= "1999-09-09";
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;
    $mail->CharSet = 'UTF-8';
    $mail->Username = "78012163912@szily.hu";
    $mail->Password = $jelszo;
    $mail->Port = 465; //587
    $mail->SMTPSecure = "ssl"; //tls
    // $file_name = "teszt.txt";
    // $mail->addAttachment("uploads/".$file_name);

    //Email Settings
    $mail->isHTML(true);
    $targy="Vásárlás";
    $mail->setFrom($email2, "A Cég");
    $mail->addAddress($email2);
    $mail->Subject = $targy;
    $mail->Body .= "Automatikus Üzenet $nev2 számára!";
    while($rekorder = mysqli_fetch_object($jatekneve)){
        $vasarlasid = $rekorder->kosarid;
        $length = 10;
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 1; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
           
        }
        
        $mail->Body .= "<tr style='text-align:justify; 'class='dropdown-item'>";
        $mail->Body .= "<td>Játék neve: $rekorder->nev </td>";
        $mail->Body .= "<td>Játék ára: $rekorder->ar-Ft </td>";
        $mail->Body .= "<td> Játék kódja: $randomString</td>";
    }
    if(!$mail->Send())
    {
       echo "Hiba a levél küldésekor. Próbálja újra!";
       exit;
    }
    
    ?>
        <script>alert("Köszönjük a vásárlást!")
    window.location.href='index.php'</script>
    <?php

  }           

  $query10 = "INSERT INTO vasarlas (datum, osszeg) VALUES (now(), $suvstr)";
  $query11 = "UPDATE vevo SET egyenleg = egyenleg - $suvstr Where vevoid = '".$_SESSION['vevoid']."'";

  $query8 = "DELETE FROM kosar WHERE vevoid = '".$_SESSION['vevoid']."'";
  mysqli_query($con,$query8) or die ('Hiba az adatbevitelnél!');
  mysqli_query($con,$query10) or die ('Hiba az adatbevitelnél!');
  mysqli_query($con,$query11) or die ('Hiba az adatbevitelnél!');
  

VerificationSend($email,$nev,$jatekneve);
}
?>

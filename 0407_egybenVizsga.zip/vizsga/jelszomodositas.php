<?php
session_start();
 
            $length = 10;
            $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';
            for ($i = 1; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
               
            }
            $_SESSION['randomString2'] = $randomString;
            $nev = $_GET['q'];
            
            //$email = $_POST['email'];

            require("kapcs.inc.php");
            $req ="SELECT * FROM vevo";
            $results = mysqli_query($con,$req) or die("Sikertelen frissítés");
            while($rekord=mysqli_fetch_object($results))
            {
                if ($rekord->nev == $nev){
                $email = $rekord->email;
                
                }
            }
            
use PHPMailer\PHPMailer\PHPMailer;


function VerificationSend($randomString2,$email2,$nev2){
    //$email = $_POST['email'];
    //Jelszó frissítése
    //$require = "UPDATE vevo SET jelszo='md5($randomString)' WHERE nev='$nev'";
    
    
    require_once "PHPMailer/PHPMailer.php";
    require_once "PHPMailer/SMTP.php";
    require_once "PHPMailer/Exception.php";

    $mail = new PHPMailer();

    //SMTP Settings
    $mail->isSMTP();
    $jelszo= "1999-09-09";
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;
    $mail->CharSet = 'UTF-8';
    $mail->Username = "78012163912@szily.hu";
    $mail->Password = $jelszo;
    $mail->Port = 465; //587
    $mail->SMTPSecure = "ssl"; //tls
    // $file_name = "teszt.txt";
    // $mail->addAttachment("uploads/".$file_name);

    //Email Settings
    $mail->isHTML(true);
    $targy="Regisztráció";
    $mail->setFrom($email2, "A Cég");
    $mail->addAddress($email2);
    $mail->Subject = $targy;
    $mail->Body = "Itten van az új jelszava vigyázzon rá!)) kedves $nev2! \n Aktiváló kódja: $randomString2";
    if(!$mail->Send())
    {
       echo "Hiba a levél küldésekor. Próbálja újra!";
       exit;
    }
    
    echo "Sikeresen elküldtük az ellenörző kódot, amit a lenti űrlapba kell beillesztenie!<br>";
    $_SESSION['randomString2'] = $randomString2;
    //$mail->send();
    //Űrlap
    // print("<form action='jelszo_mod.php' method='post'>");
    // print("Név: <input type='text' id='nev3' name='nev3'><br>");
    // print("Ellenörző kód: <input type='password' id='ekod' name='ekod'><br>");
    // print("Új jelszó: <input type='password' name='jelszo1'><br>");
    // print("Új jelszó mégegyszer: <input type='password' name='jelszo2'><br>");
    // print("<input type='submit' value='Elküldés' name='gomb'><br>");
    // print("</form>");
  }
 
    include "jelszo_mod.php";              



VerificationSend($randomString,$email,$nev);
?>

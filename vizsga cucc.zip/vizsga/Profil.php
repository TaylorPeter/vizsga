<?php
require("Register.php");

?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body> 
    <?php if(!isset($_POST['gomb'])){
        print("<form action='Profil.php' method='post'>");
        print('    <br> Add meg az életkorod:<br> <input type="date" id="start" name="datum"
        value="-"
        min="1931-12-31" max="2003-12-31"><br>');
        print("<p></p><label>Teljes neved: </label>");
        print("<input type='text' id='nev'><br>");
        print("<label>Lakcím: </label>");
        print("<input type='text' id='lakcim'><br>");

        print("<br><input type='submit' value='save' name='gomb'><br>");
        print("</form>");
    }
    else
    {
        require("kapcs.inc.php");
        $datum = $_POST['datum'];
        //$nev = $_POST['knev2'];
        //$lakcim = $_POST['lakcim2'];
        $query = "INSERT INTO vevo (ev) VALUES ('$datum')";
        mysqli_query($con,$query) or die ('Hiba az adatbevitelnél!');
        print("Adatlap elmentve!");
    } ?>
    
</body>
</html>
<?php
include "header.php";
print("<link rel='stylesheet' href='teszt.css'>");

require("kapcs.inc.php");

$jatek = mysqli_query($con,"SELECT * FROM termek") or die ("Nem sikerült a lekérdezés!");

print("<div class='container'>");


while($rekord = mysqli_fetch_object($jatek)){

echo"
                <div class='row md mt'>
                <div class='col-sm col-md col-lg'>
                <div class='card' style='float: left;' >
                    <div class='card-body text-center'>
                    <img src=".$rekord->kep." width='200'  height='200' style='overflow: hidden;'>
                    <div class'card-body'><h5>".$rekord->nev."</h5>

                        <p>$rekord->ar Ft</p>
                        <p>$rekord->mufaj</p>

                        <form action='teszt.php'  method='post' onSubmit='location.reload()'>
                        <input type='submit' class=' btn btn-primary'  name='teszt' value='Kosárba'>

                        <input type='hidden' name='nev' value='$rekord->nev'>

                        <input type='hidden' name='ar' value='$rekord->ar'>
                        <input type='hidden' name='mufaj' value='$rekord->mufaj'>
                        <input type='hidden' name='leiras' value='$rekord->leiras'>
                        <input type='hidden' name='termekid' value='$rekord->termekid'>
                        
                        </form>
                    </div>
                    </div>        
                </div>";

}

if(isset($_POST['teszt']) && isset($_SESSION['vevoid'])){
    $nev = $_POST['nev'];
    $ar = $_POST['ar'];
    $mufaj = $_POST['mufaj'];
    $leiras = $_POST['leiras'];
    $termekid = $_POST['termekid'];
    $vevoid = $_SESSION['vevoid'];
    $sql = "INSERT INTO kosar (termekid,vevoid,ar) VALUE ('$termekid','$vevoid','$ar');";
    print($nev);
    mysqli_query($con,$sql) or die ("Sikertelen adatbeszúrás");
    print("<meta http-equiv='refresh' content='0'> Sikeres kosárba helyezés!");
    
}


print("</div>");
print("</div>");
print("</div>");
print("</div>");








?>
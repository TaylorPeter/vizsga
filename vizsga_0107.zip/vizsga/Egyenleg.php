<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="VizsgaCSS.css">
    <title>Egyenleg</title>
</head>
<body>
    
<?php
session_start();
if(!isset($_POST['gomb'])){
    print("<div id='egyenlegfeltoltes'>");
print("<form action='Egyenleg.php' method='post'><br>");
print("Összeg: <input type='number' name='egyenleg2'>");
print("<br><input type='submit' name='gomb' value='Feltöltés'><br>");
print("</form>");
print("</div>");
}
else
{
    require("kapcs.inc.php");

    $egyenleg2 = $_POST['egyenleg2'];
    $ossz = ($egyenleg2 + $_SESSION['egyenleg']);
    
    

    $query = "UPDATE vevo SET egyenleg=$ossz WHERE nev ='".$_SESSION['nev2']."';";
                mysqli_query($con,$query) or die ('Hiba az adatbevitelnél!');
                print("<script>alert('Sikeres feltöltés!'); window.location.href = 'Register.php';</script>");
}

?>

</body>
</html>
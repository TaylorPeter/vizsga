<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Webshop</title>
    <link rel="stylesheet" href="vizsga/css/bootstrap.min.css">

    <?php include "header.php"?>
</head>
<body>
    <?php

    require("kapcs.inc.php");

    $termekid = mysqli_query($con,"SELECT * FROM termek WHERE termekid='".$_GET['m']."';") or die ("Nem sikerült a lekérdezés!");
    $KivalasztottOldal = $_GET['m'];
    if($termekid->num_rows>0){
    while($row = $termekid->fetch_assoc()){
        $nev = $row["nev"];
        $ar  = $row["ar"];
        $mufaj = $row["mufaj"];
        $leiras = $row["leiras"];
        $kep = $row["kep"];
        ?>

        <?php
    }}
    
    ?>
<div class="container mt-5 mb-5">
    <div class="row d-flex justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="row">
                    <div class="col-md-6">
                        <div class="images p-3">
                        <?php   print("<div class='text-center p-4'> <img id='main-image' src=' $kep' width='300' /> </div>"); ?>
                            
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="product p-4">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="d-flex align-items-center"> <i class="fa fa-long-arrow-left"></i> </div> <i class="fa fa-shopping-cart text-muted"></i>
                            </div>
                            <div class="mt-4 mb-3"> <span class="text-uppercase text-muted brand"><?php print("$mufaj"); ?></span>
                                <h5 class="text-uppercase"><?php print("$nev"); ?></h5>

                            </div>
                            <p class="about"><?php print("$leiras"); ?></p>
                            <div class="price d-flex flex-row align-items-center "> 
                                <span class="act-price"><?php print("$ar"); ?>Ft</span>
                                   
                                </div>
                            <div class="cart mt-4 align-items-center"> <button class="btn btn-primary text-uppercase mr-2 px-4">Kosárhoz Adás</button> <i class="fa fa-heart text-muted"></i> <i class="fa fa-share-alt text-muted"></i> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
                                   
   

</body>
</html>
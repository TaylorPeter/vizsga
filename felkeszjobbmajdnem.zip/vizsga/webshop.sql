-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2022. Ápr 27. 14:50
-- Kiszolgáló verziója: 10.4.22-MariaDB
-- PHP verzió: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `webshop`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `kosar`
--

CREATE TABLE `kosar` (
  `kosarid` bigint(20) NOT NULL,
  `termekid` bigint(20) NOT NULL,
  `vevoid` bigint(20) NOT NULL,
  `ar` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `kosar`
--

INSERT INTO `kosar` (`kosarid`, `termekid`, `vevoid`, `ar`) VALUES
(28, 10, 9, 2000),
(29, 10, 9, 2000),
(30, 10, 9, 2000),
(31, 11, 9, 7000),
(32, 11, 9, 7000),
(33, 11, 9, 7000),
(34, 0, 9, 0),
(35, 11, 9, 7000),
(36, 11, 9, 7000),
(37, 0, 9, 0),
(38, 10, 9, 2000),
(39, 10, 9, 2000),
(40, 10, 9, 2000),
(41, 10, 9, 2000),
(42, 10, 9, 2000),
(43, 10, 9, 2000),
(44, 10, 9, 2000),
(45, 10, 9, 2000),
(46, 10, 9, 2000),
(47, 10, 9, 2000),
(48, 10, 9, 2000),
(49, 10, 9, 2000),
(50, 10, 9, 2000),
(51, 10, 9, 2000),
(52, 10, 9, 2000),
(53, 10, 9, 2000),
(54, 10, 9, 2000),
(55, 10, 9, 2000),
(56, 10, 9, 2000),
(57, 10, 9, 2000),
(58, 10, 9, 2000),
(59, 11, 9, 7000);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `termek`
--

CREATE TABLE `termek` (
  `termekid` bigint(20) NOT NULL,
  `nev` varchar(30) COLLATE utf8_hungarian_ci NOT NULL,
  `ar` int(6) NOT NULL,
  `mufaj` varchar(20) COLLATE utf8_hungarian_ci NOT NULL,
  `leiras` varchar(400) COLLATE utf8_hungarian_ci NOT NULL,
  `kep` varchar(100) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `termek`
--

INSERT INTO `termek` (`termekid`, `nev`, `ar`, `mufaj`, `leiras`, `kep`) VALUES
(9, 'GTA6', 435345, 'singleplayer', 'zu56u', 'kepek/gta6.jpg'),
(10, 'valami', 2000, 'Mmorpg', 'asd', 'kepek/gta6.jpg'),
(11, 'No Mans Sky', 7000, 'Singleplayer', 'No Mans Sky is a space exploration game and the story is heavily focused on it. As the game progresses you will learn more about the universe you are playing in, including the portals, and the true nature of a mysterious entity called Atlas.', 'kepek/nomans.png');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `vasarlas`
--

CREATE TABLE `vasarlas` (
  `vasarlasid` bigint(20) NOT NULL,
  `datum` date NOT NULL,
  `osszeg` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `vevo`
--

CREATE TABLE `vevo` (
  `vevoid` bigint(20) NOT NULL,
  `nev` varchar(30) COLLATE utf8_hungarian_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `jelszo` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `emlek` varchar(20) COLLATE utf8_hungarian_ci NOT NULL,
  `egyenleg` int(10) NOT NULL,
  `jatekok` int(10) NOT NULL,
  `ev` date NOT NULL,
  `tnev` varchar(30) COLLATE utf8_hungarian_ci NOT NULL,
  `lakcim` varchar(60) COLLATE utf8_hungarian_ci NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `profilkepek` varchar(30) COLLATE utf8_hungarian_ci NOT NULL DEFAULT 'profilkepek/ujfelhasznalo.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `vevo`
--

INSERT INTO `vevo` (`vevoid`, `nev`, `email`, `jelszo`, `emlek`, `egyenleg`, `jatekok`, `ev`, `tnev`, `lakcim`, `admin`, `profilkepek`) VALUES
(7, 'a', 'a@a.a', 'c4ca4238a0b923820dcc509a6f75849b', '', 0, 0, '2003-12-10', 'Pumped Gáborka', 'Olümposz', 1, 'profilkepek/Among_Us.png'),
(8, 'asd', 'Szericsi00@gmail.com', '202cb962ac59075b964b07152d234b70', 'dsa vissza', 0, 0, '0000-00-00', '', '', 1, 'profilkepek/ujfelhasznalo.png'),
(9, 'asdasd', 'szericsi00@outlook.hu', '7815696ecbf1c96e6894b779456d330e', 'asd', 0, 0, '2022-04-17', 'asdwjnaw', 'Olümposza', 0, 'profilkepek/nomans.png');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `kosar`
--
ALTER TABLE `kosar`
  ADD PRIMARY KEY (`kosarid`);

--
-- A tábla indexei `termek`
--
ALTER TABLE `termek`
  ADD PRIMARY KEY (`termekid`);

--
-- A tábla indexei `vasarlas`
--
ALTER TABLE `vasarlas`
  ADD PRIMARY KEY (`vasarlasid`);

--
-- A tábla indexei `vevo`
--
ALTER TABLE `vevo`
  ADD PRIMARY KEY (`vevoid`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `kosar`
--
ALTER TABLE `kosar`
  MODIFY `kosarid` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT a táblához `termek`
--
ALTER TABLE `termek`
  MODIFY `termekid` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT a táblához `vasarlas`
--
ALTER TABLE `vasarlas`
  MODIFY `vasarlasid` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `vevo`
--
ALTER TABLE `vevo`
  MODIFY `vevoid` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php

    if(!isset($_POST['gomb1'])){

   ?>
    <p>Az emailben kapott kódot kérjük ide illesze be</p>
    <form  action="jelszo_mod.php" method="post" enctype='multipart/form-data'>

      <i class="fas fa-user fa-lg me-3 fa-fw"></i>
      <div class="form-outline flex-fill ">
        <input type="text" id='nev3' name='nev3' class="form-control" />
        <label class="form-label" for="form3Example1c">Felhasználónév</label>
      </div>


      <i class="fas fa-user fa-lg me-3 fa-fw"></i>
      <div class="form-outline flex-fill ">
        <input type="password" id='ekod' name='ekod'  class="form-control" />
        <label class="form-label" for="form3Example1c">Kód</label>
      </div>

      <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
      <div class="form-outline flex-fill ">
        <input type="password" id='jelszo1' name='jelszo1'  class="form-control" />
        <label class="form-label" for="form3Example1c">Jelszó</label>
        </div>


      <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
      <div class="form-outline flex-fill ">
        <input type="password" id='jelszo2' name='jelszo2' class="form-control" />
        <label class="form-label" for="form3Example1c">Jelszó újra</label>
        </div>

    <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
    <input type='submit' value='Elküldés' name='gomb1' class="btn btn-secondary btn-lg" ><br>

 
    </div>
    </form> 

    <?php
    }
    else
    {
        session_start();
        $randomString = $_SESSION['randomString2'];
        if($randomString == $_POST['ekod'] && $_SESSION['nev4'] == $_POST['nev3'])
        {
           $nev3 = $_POST['nev3'];
           $jelszo1 = $_POST['jelszo1'];
           $jelszo2 = $_POST['jelszo2'];
           $jelszomd5 = md5($jelszo2);
           if($jelszo1 == $jelszo2)
           {
               require("kapcs.inc.php");
               $require = "UPDATE vevo SET jelszo='$jelszomd5' WHERE nev='$nev3'";
               mysqli_query($con,$require);
           }
           else
           {
            print("<script>alert('Nem egyforma jelszót adtál meg!'); window.location.href = 'Bejelentkezescssel.php';</script>");
           }
        }
        else
        {
          print("<script>alert('Sikertelen Jelszó változtatás!'); window.location.href = 'Bejelentkezescssel.php';</script>");
        }

    //     $nev3 = $_POST['nev3'];
    //     $jelszo1 = $_POST['jelszo1'];
    //     $jelszo2 = $_POST['jelszo2'];
    //     $jelszomd5 = md5($jelszo2);
    //     $ekod = $_POST['ekod'];
        
    //   if($ekod == $_SESSION['randomString'])
    //   {
    //      if($jelszo1 == $jelszo2)
    //      {
    //          require("kapcs.inc.php");
    //          $require = "UPDATE vevo SET jelszo='$jelszomd5' WHERE nev='$nev3'";
    //          msqli_query($con,$require);
    //      }
    //      else
    //      {
    //          echo("Nem egyforma a két jelszó!/Nem jó az ellenörző kód, add meg újra!");
    //      }
    //   }
    //   else
    //   {
    //       echo("Nem egyforma a két jelszó!/Nem jó az ellenörző kód, add meg újra!");
    //   }
    // }
    print("<script>alert('Sikeres Jelszó változtatás!'); window.location.href = 'Bejelentkezescssel.php';</script>");

    }
    ?>
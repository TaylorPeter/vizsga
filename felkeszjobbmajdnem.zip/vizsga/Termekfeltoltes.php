<?php
include "header.php";



if(isset($_SESSION['nev'])){

  require("kapcs.inc.php");
  $admin = mysqli_query($con,"SELECT admin FROM vevo WHERE nev ='".$_SESSION['nev']."'") or die;
  $rekord = mysqli_fetch_object($admin);

if($rekord->admin == 1){


if(!isset($_POST['gomb'])){
  
    
    ?>
<section class="vh-100">
  <div class="container h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-lg-12 col-xl-11">
        <div class="card text-black" style="border-radius: 25px;">
          <div class="card-body p-md-5">
            <div class="row justify-content-center">
              <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">


                <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Termékfeltöltés</p>
                <?php  print("<form action='Termekfeltoltes.php' method='post' enctype='multipart/form-data'>");?>
                <form class="mx-1 mx-md-4">

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="text" name='nev' id="form3Example1c" class="form-control" />
                      <label class="form-label" for="form3Example1c">Játék neve</label>
                    </div>
                  </div>

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="number" name='ar' id="form3Example3c" class="form-control" />
                      <label class="form-label" for="form3Example3c">Ár</label>
                    </div>
                  </div>

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="text" name='mufaj' list="mufaj" class="form-control" />
                  
                      <datalist id='mufaj'>
                      <option value='Singleplayer'>Singleplayer</option>
                      <option value='Mmorpg'>Mmorpg</option>
                      <option value='Multiplayer'>Multiplayer</option>
                      <option value='FPS'>FPS</option>
                      </datalist>
                      <label class="form-label" for="form3Example3c">Típus</label>
                    </div>
                  </div>

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-key fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <textarea type="text" name='leiras' id="form3Example4cd" class="form-control" style="height='200';"></textarea>
                      <label class="form-label" for="form3Example4cd">Leírás</label>
                    </div>
                  </div>
                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-key fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                    <label for="kep" class="btn btn-primary ">
                    
                    Játék képe
                    </label>
                    <input type="file" class="btn btn-primary " id='kep' name='kep'>
                    <style>
                          input[type="file"] {
                            display: none;
                                        }
                    </style>
                      <label class="form-label" for="form3Example4cd"></label>
                    </div>
                  </div>
                  
                  <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                    <button type="submit"  name='gomb' class="btn btn-primary btn-lg">Feltöltés</button>
                  </div>
                  </form>
                </form>


              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
    <?php
    // print("Játék neve: <input type='text' name='nev'><br>");
    // print("Ár: <input type='number' name='ar'><br>");
    // //print("Kulcs: <input type='text' name='kulcs'><br>")

    // print("<label for='mufaj'>Műfajok: </label> ");
    // print("<select name='mufaj'>");
    // print("<option value='singleplayer'>Singleplayer</option>");
    // print("<option value='mmorpg'>mmorpg</option>");
    // print("<option value='multiplayer'>Multiplayer</option>");
    // print("<option value='fps'>FPS</option>");
    // print("</select><br>");

    // //print("Leiras: <input type='textbox' name='leiras'><br>");
    // print("Leírás:<br> <textarea name='leiras' rows='5' cols='50'></textarea><br>");
    // print("Kép: <input type='file' name='kep' ><br>");
    // print("<br><input type='submit' name='gomb' value='Rögzítés'><br>");
    
    print("</form>");

}
else
{

    require("kapcs.inc.php");

    $nev = $_POST['nev'];
    $ar = $_POST['ar'];
    $mufaj = $_POST['mufaj'];
    $leiras = $_POST['leiras'];
   

    
    $target_dir = "kepek/";
    $target_file = $target_dir . basename($_FILES["kep"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    
    // Check if image file is a actual image or fake image
    if(isset($_POST["gomb"])) {
      $check = getimagesize($_FILES["kep"]["tmp_name"]);
      if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
      } else {
        echo "File is not an image.";
        $uploadOk = 0;
      }
    }
    
    // Check if file already exists
    if (file_exists($target_file)) {
      echo "Sorry, file already exists.";
      $uploadOk = 0;
    }
    
    // Check file size
    if ($_FILES["kep"]["size"] > 5000000) {
      echo "Sorry, your file is too large.";
      $uploadOk = 0;
    }
    
    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
      echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
      $uploadOk = 0;
    }
    
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk != 0) {
      echo "Sorry, your file was not uploaded.";
    // if everything is ok, try to upload file
    } else {
      if (move_uploaded_file($_FILES["kep"]["tmp_name"], $target_file)) {
        echo "The file ". htmlspecialchars( basename( $_FILES["kep"]["name"])). " has been uploaded.";
      } else {
        echo "Sorry, there was an error uploading your file.";
      }
    }
    
    


   
        
                $kep = "kepek/".$_FILES["kep"]["name"];
                $query1 = "INSERT INTO termek (nev, ar, mufaj, leiras, kep) VALUES ('$nev','$ar','$mufaj','$leiras','$kep')";
                mysqli_query($con,$query1) or die ('Hiba az adatbevitelnél!');
                print("<br>Játék adatai feltöltve!");
                
        
    }
 
  }
  else{
    print("Az oldal megynitásához admin jogosultság szükséges.");
  }
}
else{
  print("Az oldal megynitásához be kell lépned!");
}  
    
    


?>
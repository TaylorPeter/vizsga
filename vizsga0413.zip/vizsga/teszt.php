<?php
include "header.php";
print("<link rel='stylesheet' href='teszt.css'>");

require("kapcs.inc.php");

$jatek = mysqli_query($con,"SELECT * FROM termek") or die ("Nem sikerült a lekérdezés!");

print("<div class='container'>");
print("");


while($rekord = mysqli_fetch_object($jatek)){

echo"
                <div class='row md mt'>
                <div class='col-sm col-md col-lg'>
                <div class='card' style='float: left;' >
                    <div class='card-body text-center'>
                        <img src='".$rekord->kep."' width='200'  height='200' style='overflow: hidden;'>
                    <div class'card-body'><h5>".$rekord->nev."</h5>
                        <p>".$rekord->ar."</p>
                        <input type='submit' class=' btn btn-primary' name='".$rekord->termekid."' value='Kosárba'>
                    </div>
                    </div>        
                </div>";

}


print("</div>");
print("</div>");
print("</div>");
print("</div>");








?>
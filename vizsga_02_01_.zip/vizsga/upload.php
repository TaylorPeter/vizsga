<?php

    print("<form action='upload.php' method='post' enctype='multipart/form-data'>");
    print("Játék neve: <input type='text' name='nev'><br>");
    print("Ár: <input type='number' name='ar'><br>");
    //print("Kulcs: <input type='text' name='kulcs'><br>");

    ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script>
 
    $(document).ready(function() {
	 
     $("#gomb2").on('click', function(){

             req.open("get", "general.php", true);
             req.send();
     });

     
     
 });
    var req = new XMLHttpRequest();
    req.onload = function(){
    $('#kod').val(this.responseText);
    };
    
    </script>
    <?php

    print("<input type='button' id='gomb2' value='kulcs generálás'>");
    print("<input type='text' name='kulcs' id='kod'><br>");

    print("<label for='mufaj'>Műfajok: </label> ");
    print("<select name='mufaj'>");
    print("<option value='singleplayer'>Singleplayer</option>");
    print("<option value='mmorpg'>mmorpg</option>");
    print("<option value='multiplayer'>Multiplayer</option>");
    print("<option value='fps'>FPS</option>");
    print("</select><br>");

    //print("Leiras: <input type='textbox' name='leiras'><br>");
    print("Leírás:<br> <textarea name='leiras' rows='5' cols='50'></textarea><br>");
    print("Kép: <input type='file' name='kep' ><br>");
    print("<br><input type='submit' name='gomb' value='Rögzítés'><br>");
    
    print("</form>");


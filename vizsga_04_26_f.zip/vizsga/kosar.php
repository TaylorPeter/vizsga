
<?php
require("kapcs.inc.php");
include "header.php";
print("<link rel='stylesheet' href='teszt.css'>");


?>
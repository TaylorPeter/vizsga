<?php
include "header.php";


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
<div class="bg-dark vh-100 d-flex justify-content-center align-items-center">
    <div class="container d-flex justify-content-center">
        <div class="card p-2">
            <div class="p-info px-3 py-3">
                <div>
                    <h5 class="mb-0">Beats By Dre</h5> <span>Professional Headphones</span>
                </div>
                <div class="p-price d-flex flex-row"> <span>$</span>
                    <h1>299</h1>
                </div>
                <div class="heart"> <i class="bx bx-heart"></i> </div>
            </div>
            <div class="text-center p-image"> <img src="https://i.imgur.com/hpftqCo.png"> </div>
            <div class="p-about">
                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed</p>
            </div>
            <div class="buttons d-flex flex-row gap-3 px-3"> <button class="btn btn-danger w-100">View</button> <button class="btn btn-outline-danger w-100">Buy Now</button> </div>
        </div>


        <div class="card p-2">
            <div class="p-info px-3 py-3">
                <div>
                    <h5 class="mb-0">Beats By Dre</h5> <span>Professional Headphones</span>
                </div>
                <div class="p-price d-flex flex-row"> <span>$</span>
                    <h1>299</h1>
                </div>
                <div class="heart"> <i class="bx bx-heart"></i> </div>
            </div>
            <div class="text-center p-image"> <img src="https://i.imgur.com/hpftqCo.png"> </div>
            <div class="p-about">
                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed</p>
            </div>
            <div class="buttons d-flex flex-row gap-3 px-3"> <button class="btn btn-danger w-100">View</button> <button class="btn btn-outline-danger w-100">Buy Now</button> </div>
        </div>
    </div>
</div>
    
</body>
</html>
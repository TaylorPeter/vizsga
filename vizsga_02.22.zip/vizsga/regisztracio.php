<?php
error_reporting(E_ERROR | E_PARSE);
if(!isset($_POST['gomb'])){
    print("<form action='regisztracio.php' method='post'><br>");
    print("Felhasználónév: <input type='text' name='nev'><br>");
    print("E-mail cím: <input type='email' name='email'><br>");
    print("Jelszó: <input type='password' name='jelszo'><br>");
    print("Jelszó mégegyszer: <input type='password' name='jelszo2'><br>");
    print("<input type='submit' name='gomb' value='Regisztráció'><br>");
    
    print("</form>");

}
else{

    require("kapcs.inc.php");

    $nev = $_POST['nev'];
    $email = $_POST['email'];
    $jelszo = md5($_POST['jelszo']);
    $jelszo2 = md5($_POST['jelszo2']);



    
    

    if($nev == NULL || $email == NULL || $jelszo == NULL)
    {
        print("<script>alert('Üres mező!'); window.location.href = 'regisztracio.php';</script>");
    }
    elseif($jelszo != $jelszo2)
    {
        print("<script>alert('A jelszavak nem egyeznek!'); window.location.href = 'regisztracio.php';</script>");
    }
    else
    {

        $sql = "SELECT * FROM vevo WHERE email='$email' LIMIT 1";
        $result = mysqli_query($con, $sql);
        $felhasznalo = mysqli_fetch_assoc($result);
        if($felhasznalo){
            if($felhasznalo['email'] === $email )
            {
                print("<script>alert('Ezzel az email címmel már regisztráltak!'); window.location.href = 'regisztracio.php';</script>");
                
            }

            
        
        }
        $sql = "SELECT * FROM vevo WHERE nev='$nev' LIMIT 1";
        $result = mysqli_query($con, $sql);
        $felhasznalo = mysqli_fetch_assoc($result);
        if($felhasznalo){
            if($felhasznalo['nev'] === $nev )
            {
                print("<script>alert('Ilyen néven már regisztráltak!'); window.location.href = 'regisztracio.php';</script>");
                
            }

            
        
        }
        else
        {
                $query = "INSERT INTO vevo (nev, email, jelszo) VALUES ('$nev','$email','$jelszo')";
                mysqli_query($con,$query) or die ('Hiba az adatbevitelnél!');
                print("Sikeres regisztráció!");
                require("kuldo.php");

                print("<script>window.location.href = 'Bejelentkezes.php';</script>");
        }
    }
 

}   
    
    
    


?>
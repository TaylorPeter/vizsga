<?php
    session_start();
    print($_SESSION['randomString']);

?>
<?php
session_start();
            $length = 10;
            $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';
            for ($i = 1; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
               
            }
            
            $nev = $_GET['q'];
            
            //$email = $_POST['email'];

            require("kapcs.inc.php");
            $req ="SELECT * FROM vevo";
            $results = mysqli_query($con,$req) or die("Sikertelen frissítés");
            while($rekord=mysqli_fetch_object($results))
            {
                if ($rekord->nev == $nev){
                $email = $rekord->email;
                
                }
            }
use PHPMailer\PHPMailer\PHPMailer;


function VerificationSend($randomString2,$email2,$nev2){
    //$email = $_POST['email'];
    //Jelszó frissítése
    //$require = "UPDATE vevo SET jelszo='md5($randomString)' WHERE nev='$nev'";
    
    
    require_once "PHPMailer/PHPMailer.php";
    require_once "PHPMailer/SMTP.php";
    require_once "PHPMailer/Exception.php";

    $mail = new PHPMailer();

    //SMTP Settings
    $mail->isSMTP();
    $jelszo= "1999-09-09";
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;
    $mail->CharSet = 'UTF-8';
    $mail->Username = "78012163912@szily.hu";
    $mail->Password = $jelszo;
    $mail->Port = 465; //587
    $mail->SMTPSecure = "ssl"; //tls
    // $file_name = "teszt.txt";
    // $mail->addAttachment("uploads/".$file_name);

    //Email Settings
    $mail->isHTML(true);
    $targy="Regisztráció";
    $mail->setFrom($email2, "A Cég");
    $mail->addAddress($email2);
    $mail->Subject = $targy;
    $mail->Body = "Itten van az új jelszava vigyázzon rá!)) kedves $nev2! \n Aktiváló kódja: $randomString2";
    if(!$mail->Send())
    {
       echo "Hiba a levél küldésekor. Próbálja újra!";
       exit;
    }
    
    echo "Sikeresen elküldtük az ellenörző kódot, amit a lenti űrlapba kell beillesztenie!<br>";
    $_SESSION['randomString2'] = $randomString2;
    //$mail->send();
    //Űrlap
    // print("<form action='jelszo_mod.php' method='post'>");
    // print("Név: <input type='text' id='nev3' name='nev3'><br>");
    // print("Ellenörző kód: <input type='password' id='ekod' name='ekod'><br>");
    // print("Új jelszó: <input type='password' name='jelszo1'><br>");
    // print("Új jelszó mégegyszer: <input type='password' name='jelszo2'><br>");
    // print("<input type='submit' value='Elküldés' name='gomb'><br>");
    // print("</form>");
  }

    if(!isset($_POST['gomb5'])){
   ?>
    <form action="Bejelentkezescssel.php" method="post">
    <div class="d-flex flex-row align-items-center mb-0">
      <i class="fas fa-user fa-lg me-3 fa-fw"></i>
      <div class="form-outline flex-fill mb-0">
        <input type="text" id='nev3' name='nev3' class="form-control" />
        <label class="form-label" for="form3Example1c">Felhasználónév</label>
      </div>
    </div>
    <div class="d-flex flex-row align-items-center mb-0">
      <i class="fas fa-user fa-lg me-3 fa-fw"></i>
      <div class="form-outline flex-fill mb-0">
        <input type="password" id='ekod' name='ekod'  class="form-control" />
        <label class="form-label" for="form3Example1c">Kód</label>
      </div>
    </div>
    
    <div class="d-flex flex-row align-items-center mb-0">
      <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
      <div class="form-outline flex-fill mb-0">
        <input type="password" id='jelszo1' name='jelszo1'  class="form-control" />
        <label class="form-label" for="form3Example1c">Jelszó</label>
        </div>
    </div>
    <div class="d-flex flex-row align-items-center mb-0">
      <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
      <div class="form-outline flex-fill mb-0">
        <input type="password" id='jelszo2' name='jelszo2' class="form-control" />
        <label class="form-label" for="form3Example1c">Jelszó újra</label>
        </div>
    </div>
    <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
    <input type='submit' value='Elküldés' name='gomb5' class="btn btn-secondary btn-lg"><br>
    <?php print($randomString);?>
 
    </div>
    </form> 

    <?php
    }
    else
    {
      $randomString = $_SESSION['randomString'];
      if($_POST['ekod'] == $randomString)
      {
         $nev3 = $_POST['nev3'];
         $jelszo1 = $_POST['jelszo1'];

         $jelszo2 = $_POST['jelszo2'];
         $jelszomd5 = md5($jelszo2);
         $ekod = $_POST['ekod'];
         if($ekod == $randomString && $jelszo1 == $jelszo2)
         {
             require("kapcs.inc.php");
             $require = "UPDATE vevo SET jelszo='$jelszomd5' WHERE nev='$nev3'";
             msqli_query($con,$require);
         }
         else
         {
             alert("Nem egyforma a két jelszó!/Nem jó az ellenörző kód, add meg újra!");
         }
      }
      else
      {
          alert("Nem egyforma a két jelszó!/Nem jó az ellenörző kód, add meg újra!");
      }
    }
                  



VerificationSend($randomString,$email,$nev);
?>

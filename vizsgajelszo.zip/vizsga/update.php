<?php
$q = $_GET['q'];
$q2 = $_GET['p'];
require("kapcs.inc.php");
if($q2 == 1){
     $q3 = mysqli_query($con,"UPDATE vevo SET admin='0' WHERE vevoid='".$q."'") or die;
    
}
else
{
     $q3 = mysqli_query($con,"UPDATE vevo SET admin='1' WHERE vevoid='".$q."'") or die;
    
}
print($q2);
?>
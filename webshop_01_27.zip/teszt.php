
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script>
 
 $(document).ready(function() {
	 
        $("#gomb").on('click', function(){

                 //$("#kod").load("general.php");
                 //document.getElementById("kod").value = $('#kod').load('general.php');
                 req.open("get", "general.php", true);
                req.send();
		});

		
		
    });
var req = new XMLHttpRequest();
req.onload = function(){
    $('#kod').val(this.responseText);
};

</script>
<?php
print("<form>");
print("<input type='button' id='gomb' value='hello'>");
print("<input type='text' id='kod'>");
print("</form>");


?>

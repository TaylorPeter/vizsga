﻿

<?php
require('fpdf/fpdf184/fpdf.php');
function decode($szoveg){
	$str = iconv('UTF-8', 'windows-1252',$szoveg);
	return $str;
}

$pdf = new FPDF();

$pdf->AddPage();
/*output the result*/

// $pdf->AddFont('Malgunn','','malgunn_boot.php',true);
// $pdf->SetFont('Malgunn', 'B',20);
/*set font to arial, bold, 14pt*/
/*Cell(width , height , text , border , end line , [align] )*/

// $fontName = 'Helvetica';
// $pdf->AddFont($fontName,'','fpdf/fpdf184/font/helvetica.php',true);
// $pdf->SetFont($fontName,'B',12);
$pdf->SetFont('Arial','B',16);





$pdf->Cell(71 ,10,'',0,0);
$str = "Számla";
$str = decode($str);
$pdf->Cell(59 ,5,$str,0,0);
$pdf->Cell(59 ,10,'',0,1);

$pdf->SetFont('Arial','B',15);
$str = "Eladó";
$str = decode($str);
$pdf->Cell(71 ,5,$str,0,0);
$pdf->Cell(59 ,5,'',0,0);
$pdf->Cell(59 ,5,'Adatok',0,1);

$pdf->SetFont('Arial','',10);

$pdf->Cell(130 ,5,'Hely',0,0);
$str = "Vásárló név:";
$str = decode($str);
$pdf->Cell(25 ,5,$str,0,0);
$pdf->Cell(34 ,5,'0012',0,1);

$pdf->Cell(130 ,5,'Delhi, 751001',0,0);
$str = "Számla kelte:";
$str = decode($str);
$pdf->Cell(25 ,5,$str,0,0);
$pdf->Cell(34 ,5,'12th Jan 2019',0,1);
 
$pdf->Cell(130 ,5,'',0,0);
$str = "Számla száma:";
$str = decode($str);
$pdf->Cell(25 ,5,$str,0,0);
$pdf->Cell(34 ,5,'ORD001',0,1);


$pdf->SetFont('Arial','B',15);
$str = "Számla";
$str = decode($str);
$pdf->Cell(130 ,5,$str,0,0);
$pdf->Cell(59 ,5,'',0,0);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(189 ,10,'',0,1);



$pdf->Cell(50 ,10,'',0,1);

$pdf->SetFont('Arial','B',10);
/*Heading Of the table*/
$pdf->Cell(10 ,6,'Sl',1,0,'C');
$str = "Leírás:";
$str = decode($str);
$pdf->Cell(80 ,6,$str,1,0,'C');
$str = "Mennyiség";
$str = decode($str);
$pdf->Cell(23 ,6,$str,1,0,'C');
$str = "Nettó Ár";
$str = decode($str);
$pdf->Cell(30 ,6,$str,1,0,'C');
$str = "Áfa";
$str = decode($str);
$pdf->Cell(20 ,6,$str,1,0,'C');
$str = "Bruttó Ár";
$str = decode($str);
$pdf->Cell(25 ,6,$str,1,1,'C');/*end of line*/
/*Heading Of the table end*/
$pdf->SetFont('Arial','',10);
    for ($i = 1; $i <= 10; $i++) {
		$pdf->Cell(10 ,6,$i,1,0);
		$pdf->Cell(80 ,6,"sql adatbazis",1,0);
		$pdf->Cell(23 ,6,'1',1,0,'R');
		$pdf->Cell(30 ,6,'15000.00',1,0,'R');
		$pdf->Cell(20 ,6,'100.00',1,0,'R');
		$pdf->Cell(25 ,6,'15100.00',1,1,'R');
	}
		

$pdf->Cell(118 ,6,'',0,0);
$str = "Végösszeg";
$str = decode($str);
$pdf->Cell(25 ,6,$str,0,0);
$pdf->Cell(45 ,6,'151000.00',1,1,'R');


$pdf->Output();
?>

﻿<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>
<?php
use PHPMailer\PHPMailer\PHPMailer;
function VerificationSend(){
    $email = $_POST['email'];
    $nev = $_POST['nev'];


    require_once "PHPMailer/PHPMailer.php";
    require_once "PHPMailer/SMTP.php";
    require_once "PHPMailer/Exception.php";

    $mail = new PHPMailer();

    //SMTP Settings
    $mail->isSMTP();
    $jelszo= "1999-09-09";
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;
    $mail->CharSet = 'UTF-8';
    $mail->Username = "78012163912@szily.hu";
    $mail->Password = $jelszo;
    $mail->Port = 465; //587
    $mail->SMTPSecure = "ssl"; //tls
    $file_name = "teszt.txt";
    $mail->addAttachment("uploads/".$file_name);

    //Email Settings
    $mail->isHTML(true);
    $targy="Regisztráció";
    $mail->setFrom($email, "A Cég");
    $mail->addAddress($email);
    $mail->Subject = $targy;
    $mail->Body = "Sikeres regisztráció! \n Üdv az oldalon $nev!";
    if(!$mail->Send())
    {
       echo "Hiba a levél küldésekor. Próbálja újra!";
       exit;
    }
    
    echo "Az üzenet sikeresen továbbítva.";
    //$mail->send();

       
}
VerificationSend();
?>

<?php
include "header.php";


print("<link rel='stylesheet' href='VizsgaCSS.css'>");
require("kapcs.inc.php");

$jatek = mysqli_query($con,"SELECT * FROM termek") or die ("Nem sikerült a lekérdezés!");


while($rekord = mysqli_fetch_object($jatek)){
print("<form action='teszt.php' method='post'>");
print("<div class='jatek'><img src='".$rekord->kep."' height='200px' width='200px'><p>".$rekord->nev."</p><p>".$rekord->ar."</p><input type='submit' name='".$rekord->termekid."' value='Kosárba'></div>");
if(isset($_POST["'".$rekord->termekid."'"])){

    
//   $query = "INSERT INTO kosar (termekid, vevoid) VALUES ($rekord->termekid, $_SESSION['vevoid'])";
//   mysqli_query($con,$query) or die ('Hiba az adatbevitelnél!');

}
print("</form>");

}






?>
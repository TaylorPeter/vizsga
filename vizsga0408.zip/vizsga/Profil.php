<?php
include "header.php";

?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body> 

    <?php if(!isset($_POST['gomb'])){
      $ev_="";
      $tnev_ = "";
      $lakcim_ = "";
      $profilkepek_ = "";
        $query2 = "SELECT * FROM vevo WHERE nev='".$_SESSION['nev']."';";
        $result = $con->query($query2);
        if($result->num_rows>0){

        
        while($row = $result->fetch_assoc()){
            $row["tnev"] == $_SESSION['nev'];
                $ev_ = $row["ev"];
                $tnev_ = $row["tnev"];
                $lakcim_ = $row["lakcim"];
                $profilkepek_ = $row["profilkepek"];
            
            //echo $row["ev"]."<br>".$row["tnev"]."<br>".$row["lakcim"]."<br><img height='100px' width='100px' src='".$row['profilkepek']."'>";

          }

        } else{
            echo"Üres az adatbázis.";
        }
        require("kapcs.inc.php");
        ?>
<section class="vh-100" style="background-color: #eee;">
  <div class="container h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-lg-12 col-xl-11">
        <div class="card text-black" style="border-radius: 25px;">
          <div class="card-body p-md-5">
            <div class="row justify-content-center">
              <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">


                <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Profil</p>
                <?php print("<form action='profil.php' method='post'>"); ?>
                <form class="mx-1 mx-md-4">

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                    <input type='date' id='start' name='datum' value='<?php$ev_;?>'>
                      <label class="form-label" for="form3Example1c">Felhasználónév</label>
                    </div>
                  </div>

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="email" name='email' id="form3Example3c" class="form-control" />
                      <label class="form-label" for="form3Example3c">Email</label>
                    </div>
                  </div>

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="password" name='jelszo' id="form3Example4c" class="form-control" />
                      <label class="form-label" for="form3Example4c">Jelszó</label>
                    </div>
                  </div>

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-key fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="password" name='jelszo2' id="form3Example4cd" class="form-control" />
                      <label class="form-label" for="form3Example4cd">Jelszó ismét</label>
                    </div>
                  </div>
                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-key fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="text" name='emlek2' id="form3Example4cd" class="form-control" />
                      <label class="form-label" for="form3Example4cd">Jelszó Emlékeztető</label>
                    </div>
                  </div>
                  
                  <div class="form-check d-flex justify-content-center mb-5">
                    <input
                      class="form-check-input me-2"
                      type="checkbox"
                      name="agree"
                      value=""
                      id="form2Example3c"
                    />
                    <label class="form-check-label" for="form2Example3">
                      Elfogadom a  <a href="#!">Felhasználási feltételeket!</a>
                    </label>
                  </div>

                  <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                    <button type="submit"  name='gomb' class="btn btn-primary btn-lg">Regisztráció</button>
                  </div>
                  </form>
                </form>


              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

        <!-- // print("<form action='Profil.php' method='post' enctype='multipart/form-data'>");
        // print("<br> Add meg a születési dátumod:<br> <input type='date' id='start' name='datum' value='$ev_'><br>");
        // print("<p></p><label>Teljes neved: </label>");
        // print("<input type='text' id='nev' value='$tnev_' name='tnev'><br>");
        // print("<label>Lakcím: </label>");
        // print("<input type='text' id='lakcim' value='$lakcim_' name='lakcim'><br>");
        // print("<input type='file' id='profilkepek' name='profilkepek'><span name='old' value='=$profilkepek_'><br>");
        // print("<br><input type='submit' value='Mentés' name='gomb'><br>");
        // print("</form>"); -->
        <?php
    }
    else
    {
        require("kapcs.inc.php");
        $datum = $_POST['datum'];
        $tnev = $_POST['tnev'];
        $lakcim = $_POST['lakcim'];

        $target_dir = "profilkepek/";
        $target_file = $target_dir . basename($_FILES["profilkepek"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        
        // Check if image file is a actual image or fake image

        if(isset($_POST["gomb"])) {
          if($_FILES["profilkepek"]["tmp_name"] == NULL){
            $query = "UPDATE vevo SET ev='$datum', tnev='$tnev', lakcim='$lakcim' WHERE nev='".$_SESSION['nev']."';";
            mysqli_query($con,$query) or die ('Hiba az adatbevitelnél!');
            print("<script>alert('Adatlap elmentve!'); window.location.href = 'Profil.php';</script>");
          }
          $check = getimagesize($_FILES["profilkepek"]["tmp_name"]);
          if($check !== false) {
            echo "A fálj egy kép - " . $check["mime"] . ".";
            $uploadOk = 1;
          } else {
            echo "A fálj nem kép";
            $uploadOk = 0;
          }
        }
        

        
        // Check file size
        if ($_FILES["profilkepek"]["size"] > 5000000) {
          echo "A fálj túl nagy.";
          $uploadOk = 0;
        }
        
        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
          echo "Csak JPG, JPEG, PNG kép tipusok elérhetőek.";
          $uploadOk = 0;
        }
        
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
          echo "A fáljt nem lehet feltölteni.";
        // if everything is ok, try to upload file
        } else {
          if (move_uploaded_file($_FILES["profilkepek"]["tmp_name"], $target_file)) {
            $profilkepek = "profilkepek/".$_FILES["profilkepek"]["name"];
            $query = "UPDATE vevo SET ev='$datum', tnev='$tnev', lakcim='$lakcim', profilkepek='$profilkepek' WHERE nev='".$_SESSION['nev']."';";
            mysqli_query($con,$query) or die ('Hiba az adatbevitelnél!');
            print("<script>alert('Adatlap elmentve!'); window.location.href = 'Profil.php';</script>");
            echo "A fájl ". htmlspecialchars( basename( $_FILES["profilkepek"]["name"])). " sikeresen fel lett töltve.";
          } else {
            print("<script>alert('Hiab az adatbevitelkor!'); window.location.href = 'Profil.php';</script>");
          }
        }

        
        


    } 

    
    ?>
    
</body>
</html>
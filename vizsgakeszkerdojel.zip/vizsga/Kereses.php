<!DOCTYPE html>
<?php include "header.php";?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form class="d-flex">
          <input type="search" name="keywords" class="form-control me-2" placeholder="Keresés..." aria-label="Search">
         
        </form>
        <?php
        $keywords = isset($_GET['keywords']) ? '%'.$_GET['keywords'].'%' : '';

        $query = "SELECT * FROM termek where nev like '$keywords'";
        
        $result = $con->query($query);
        while($rekord = mysqli_fetch_object($result)){

          echo"
                          <div class='row md mt'>
                          <div class='col-sm col-md col-lg'>
                          <div class='card' style='float: left;' >
                              <div class='card-body text-center'>
                                  <img src='".$rekord->kep."' width='200'  height='200' style='overflow: hidden;'>
                              <div class'card-body'><h5>".$rekord->nev."</h5>
                                  <p>".$rekord->ar."</p>
                                  <a href='tesztjatekoldal.php?m=".$rekord->termekid."'>Bővebben</a>
                                  <input type='submit' class=' btn btn-primary' name='".$rekord->termekid."' value='Kosárba'>
                              </div>
                              </div>
                          </div>";
          
          }
          
          
          print("</div>");
          print("</div>");
          print("</div>");
          print("</div>");   ?>  
</body>
</html>
 
       
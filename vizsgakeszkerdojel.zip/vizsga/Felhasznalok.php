<?php
include "header.php";
if(isset($_SESSION['nev'])){

    require("kapcs.inc.php");
    print("<link rel='stylesheet' href='vizsga/VizsgaCSS.css'>");
    $admin = mysqli_query($con,"SELECT admin FROM vevo WHERE nev='".$_SESSION['nev']."'") or die;
    $rekord = mysqli_fetch_object($admin);

if($rekord->admin == 1){

$felhasznalo = mysqli_query($con,"SELECT * FROM vevo") or die ("Nem sikerült a lekérdezés!");
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    function Checked_btn($q,$rekordadmin){
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onload = function(){
            window.location.reload();
        }

    xmlhttp.open("GET", "update.php?q=" +$q+"&p="+$rekordadmin, true);
    xmlhttp.send();
}
</script>


<table>
    <tr>
        <th>Név</th>
        <th>Email</th>
        <th>Egyenleg</th>
        <th>Születési dátum</th>
        <th>Admin</th>
    </tr>
    <?php
    print("<form action='Felhasznalok.php' method='post'><br>");
while($rekord = mysqli_fetch_object($felhasznalo)){
    if($rekord->admin==1){
        $checked = 'checked';
    }
        $rekordadmin = $rekord->admin;
        $q = $rekord->vevoid;
        print("<tr><td>".$rekord->nev. "</td><td>".$rekord->email. "</td><td>".$rekord->egyenleg. "</td><td>".$rekord->ev. "</td><td>".$rekord->admin. "</td><td>");
        if($rekord->admin == 0)
        {
            print("<input type='checkbox' name='".$rekord->vevoid."' onClick='Checked_btn($q,$rekordadmin)'></tr>");
        }
        else if($rekord->vevoid == $_SESSION['vevoid'])
        {
            
        }
        else
        {
            print("<input type='checkbox' name='".$rekord->vevoid."' onClick='Checked_btn($q,$rekordadmin)' value='".$rekord->admin."'".$checked."></tr>");
        }
    

    
}
print("</table>");
print("</form>");
    }
else{
print("Az oldal megnyitásához admin jogosultság szükséges.");
    }
}
    else
    {
    print("Az oldal megnyitásához admin jogosultság szükséges.");
    }  

?>
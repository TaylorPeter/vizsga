<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Webshop</title>
    <link rel="stylesheet" href="vizsga/css/bootstrap.min.css">

    <?php include "header.php"?>
</head>
<body>
    <?php

    require("kapcs.inc.php");

    $termekid = mysqli_query($con,"SELECT * FROM termek WHERE termekid='".$_GET['m']."';") or die ("Nem sikerült a lekérdezés!");
    $KivalasztottOldal = $_GET['m'];
    if($termekid->num_rows>0){
    while($row = $termekid->fetch_assoc()){
        $nev = $row["nev"];
        $ar  = $row["ar"];
        $mufaj = $row["mufaj"];
        $leiras = $row["leiras"];
        $kep = $row["kep"];
        ?>

        <?php
    }}
    
    ?>
<div class="container mt-5 mb-5">
    <div class="row d-flex justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="row">
                    <div class="col-md-6">
                        <form action=""  method='post'  >
                        <div class="images p-3">
                        <?php   print("<div class='text-center p-4'> <img id='main-image' src=' $kep' /> </div>"); ?>
                            
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="product p-4">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="d-flex align-items-center"> <i class="fa fa-long-arrow-left"></i> </div> <i class="fa fa-shopping-cart text-muted"></i>
                            </div>
                            <div class="mt-4 mb-3"> <span class="text-uppercase text-muted brand" name="mufaj"><?php print("$mufaj"); ?></span>
                                <h5 class="text-uppercase" name="nev"><?php print("$nev"); ?></h5>
                            </div>
                            <p class="about" name="leiras"><?php print("$leiras"); ?></p>
                            <div class="price d-flex flex-row align-items-center "> 
                                <span class="act-price" name="ar"><?php print("$ar"); ?>Ft</span>
                                   
                                </div>
                            <div class="cart mt-4 align-items-center"> <input type="submit" class="btn btn-primary text-uppercase mr-2 px-4" name="teszt" value="Kosárhoz Adás"></input> <i class="fa fa-heart text-muted"></i> <i class="fa fa-share-alt text-muted"></i> </div>
                        </div>
                        
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
if(isset($_POST['teszt']) && isset($_SESSION['vevoid'])){

    $termekid = $_GET['m'];
    $vevoid = $_SESSION['vevoid'];
    $sql = "INSERT INTO kosar (termekid,vevoid,ar,nev) VALUE ('$termekid','$vevoid','$ar','$nev');";
    mysqli_query($con,$sql) or die ("Sikertelen adatbeszúrás");
    print("<meta http-equiv='refresh' content='0'>");
    
}
?>                                   
   

</body>
</html>
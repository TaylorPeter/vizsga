<?php

    require("kapcs.inc.php");
    $nev = $_GET['q'];
    $query = "SELECT * FROM vevo";
    $a = 0;


    $results = mysqli_query($con, $query);
    while($rekord=mysqli_fetch_object($results))
    {
     
        if ($rekord->nev == $nev){
        $emlek = $rekord->emlek;
        $a = 1;
     
        }
        else
        {
            if($a==0){
               $emlek="Nincs jelszó emlékeztető.";
            }
            
        }
    }

    if($emlek == ""){
        $emlek="Nincs jelszó emlékeztető.";
    }
    
 
    


?>

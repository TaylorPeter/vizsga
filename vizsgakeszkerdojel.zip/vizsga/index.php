<?php
include "header.php";
error_reporting(0);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' href='index.css'>
</head>
<body>
<div class="container"> 
<section id="sidebar">
    <div class="border-bottom pb-2 ml-2">
        <h4 id="burgundy">Játékok</h4>
    </div>
    <form action="index.php" method="post">
    <div class="py-2 border-bottom ml-3">
        <h6 class="font-weight-bold">Ár</h6>
        <div id="orange"><span class="fa fa-minus"></span></div>
     
            <div class="form-group">
            <div class="slidecontainer">
           
            <input type="text" name="min" class="form-control " placeholder="Ft-tól" href="index.php" style="padding-bottom:" aria-label="Search">
            <input type="text" name="max" class="form-control " placeholder="Ft-ig" href="index.php" aria-label="Search">

         
            </div> </div>
        
    </div>
    <div class="py-2 border-bottom ml-3">
        <h6 class="font-weight-bold">Kategóriák</h6>
        <div id="orange"><span class="fa fa-minus"></span></div>

            <div class="form-group"> <input type="radio" name="mufaj" id="Action" value="Action"> <label for="Action">Action</label> </div>
            <div class="form-group"> <input type="radio" name="mufaj" id="Adventure"  value="Adventure"> <label for="Adventure">Adventure</label> </div>
            <div class="form-group"> <input type="radio" name="mufaj" id="First-Person Shooter" value="First-Person Shooter"> <label for="First-Person Shooter">First-Person Shooter</label> </div>
            <div class="form-group"> <input type="radio" name="mufaj" id="Horror"  value="Horror"> <label for="Horror">Horror</label> </div>
            <div class="form-group"> <input type="radio" name="mufaj" id="Racing"  value="Racing"> <label for="Racing">Racing</label> </div>
            <div class="form-group"> <input type="radio" name="mufaj" id="MultiplSingleplayerayer"  value="Singleplayer"> <label for="Singleplayer">Singleplayer</label> </div>
            <div class="form-group"> <input type="radio" name="mufaj" id="Sports"  value="Sports"> <label for="Sports">Sports</label> </div>

    </div>
    <div id="orange"><span class="fa fa-minus"></span></div>
    <button type="submit"  name='kereses' class="btn btn-primary btn-lg">Keresés</button>
</form>
    </section>
<?php

if(isset($_POST['kereses'])){
    $mufaj3 = $_POST['mufaj'];
    $min = $_POST['min'];
    $max = $_POST['max'];
    if(isset($mufaj3)){
        if($max == NULL){
            $arkereso = "";
          
        }else{
            $arkereso = "AND ar BETWEEN '$min' AND '$max'";
        }
        $query6 = "SELECT * FROM termek where mufaj='$mufaj3' $arkereso";
        $keret++;
    }
    else if(isset($max) && isset($min)){
        $keret++;
        if($max < $min)
        {
           $max = 1000000;
           
        }
        $query6 = "SELECT * FROM termek where ar BETWEEN '$min' AND '$max'";
        
    }

    
}   
else if($_GET['keywords'] != "")
{
    $keywords = isset($_GET['keywords']) ? '%'.$_GET['keywords'].'%' : '';
    $keret++;
 $query6 = "SELECT * FROM termek where nev like '$keywords'";

}else{
    $keret++;
    $query6 = "SELECT * FROM termek";
}

if($keret == 1){

    ?>
        <div class='container'>
        <div class="col-md-12 mt-4">
        <div class="card ">
        <div class="card-body row">
    <?php
}


 
 $result = $con->query($query6);

 while($rekord = mysqli_fetch_object($result)){
    ?>
<div class="col-sm-3 col-md-6 col-lg-3">
  <div class="card" style="margin-bottom: 10%">
      <div class="card-body text-center" >
     <?php
   echo"
   
   
           
                  <img src='".$rekord->kep."' width='75%'  height='75%' style='overflow: hidden;'>
                  <div class'card-body'><h5>".$rekord->nev."</h5>
                  <p>".$rekord->ar."Ft</p>
                  <a href='Jatekoldal.php?m=".$rekord->termekid."'class='btn btn-primary'>Bővebben</a>
                  </div>
           </div>
           </div>
           </div>
";
 }
?>

         
   

  </div >
  <script src="index.js"></script>
</body>
</html>

























































































































































































































































































































































































































































































































































<!-- Nigger -->
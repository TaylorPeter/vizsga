<?php
session_start();
require("kapcs.inc.php");
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ROGw</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">

    
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <?php
        
        
        
    ?>
    <div>   
        <ul>
            <li><a href="Register.php">Főoldal</a></li>
            <li><a href="">Legfrissebb</a></li>
            <li><a href="">Felkapott</a></li>
            <li><a href="">Kategória</a></li>
            
                                           

        <?php 
        if(!isset($_SESSION['nev']))
        {
            print("<div class='legordulo' style='float:right;'>");
            print("<button class='legordulogomb'>Belépés</button>");
            print("<div class='legordulo-content'>");
            print("<a href='Bejelentkezes.php'>Bejelentkezés</a>");
            print("<a href='regisztracio.php'>Regisztráció</a>");
            print("</div>");
        }
        else
        {
            $egyenleg = "SELECT egyenleg FROM vevo WHERE nev ='".$_SESSION['nev']."';";
            $_SESSION['egyenleg'] = $egyenleg;
            $admin = mysqli_query($con,"SELECT admin FROM vevo WHERE nev ='".$_SESSION['nev']."'") or die;
            $rekord = mysqli_fetch_object($admin);
            $profilkep = mysqli_query($con,"SELECT profilkepek FROM vevo WHERE nev ='".$_SESSION['nev']."'") or die ("Nem sikerült a lekérdezés!");
            $prekord = mysqli_fetch_object($profilkep);

            print("<li><a href='Egyenleg.php'>Egyenleged: "); $eredmeny = $con->query($egyenleg);
                                            while($row = $eredmeny->fetch_assoc())
                                            {
                                                echo $row['egyenleg'] , "Ft";
                                            } print("</a></li>");
            print("<div class='legordulo' style='float:right;'>");
            print("<button class='legordulogomb'>".$_SESSION['nev']." "."<img id='profilkep' src='$prekord->profilkepek '></button>");
            print("<div class='legordulo-content'>");
            print("<a href='Profil.php'>Profil</a>");
            print("<a href='Egyenleg.php'>Egyenleg</a>");
            print("<a href='#'>Játékaid</a>");
            print("<a href='teszt.php'>jatekok</a>");
            if($rekord->admin == 1){
                print("<a href='Felhasznalok.php'>Felhasználók</a>");
                print("<a href='Termekfeltoltes.php'>Termékfeltöltés</a>");
            }
            print("<a href='Kijelentkezes.php'>Kijelentkezés</a>");
            print("</div>");
        }
        ?>
        
        </div>
        <header class="p-3 mb-3 border-bottom">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-dark text-decoration-none">
          <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"></use></svg>
        </a>

        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a href="#" class="nav-link px-2 link-secondary">Overview</a></li>
          <li><a href="#" class="nav-link px-2 link-dark">Inventory</a></li>
          <li><a href="#" class="nav-link px-2 link-dark">Customers</a></li>
          <li><a href="#" class="nav-link px-2 link-dark">Products</a></li>
        </ul>

        <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3">
          <input type="search" class="form-control" placeholder="Search..." aria-label="Search">
        </form>

        <div class="dropdown text-end">
          <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="https://github.com/mdo.png" alt="mdo" width="32" height="32" class="rounded-circle">
          </a>
          <ul class="dropdown-menu text-small" aria-labelledby="dropdownUser1" style="">
            <li><a class="dropdown-item" href="#">New project...</a></li>
            <li><a class="dropdown-item" href="#">Settings</a></li>
            <li><a class="dropdown-item" href="#">Profile</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Sign out</a></li>
          </ul>
        </div>
      </div>
    </div>
  </header>
  <div class="signup-content">
<div class="signup-form">
<h2 class="form-title">Sign up</h2>
<form method="POST" class="register-form" id="register-form">
<div class="form-group">
<label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
<input type="text" name="name" id="name" placeholder="Your Name">
</div>
<div class="form-group">
<label for="email"><i class="zmdi zmdi-email"></i></label>
<input type="email" name="email" id="email" placeholder="Your Email">
</div>
<div class="form-group">
<label for="pass"><i class="zmdi zmdi-lock"></i></label>
<input type="password" name="pass" id="pass" placeholder="Password">
</div>
<div class="form-group">
<label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
<input type="password" name="re_pass" id="re_pass" placeholder="Repeat your password">
</div>
<div class="form-group">
<input type="checkbox" name="agree-term" id="agree-term" class="agree-term">
<label for="agree-term" class="label-agree-term"><span><span></span></span>I agree all statements in <a href="#" class="term-service">Terms of service</a></label>
</div>
<div class="form-group form-button">
<input type="submit" name="signup" id="signup" class="form-submit" value="Register">
</div>
</form>
</div>
<div class="signup-image">
<figure><img src="images/signup-image.jpg" alt="sing up image"></figure>
<a href="#" class="signup-image-link">I am already member</a>
</div>
</div>
            
        </ul>
    </div>
        
        
    
</body>

</html>
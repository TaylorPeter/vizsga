<?php
    session_start();
     $randomString = $_SESSION['randomString'];
     if($_POST['ekod'] == $randomString)
     {
        $nev3 = $_POST['nev3'];
        $jelszo1 = $_POST['jelszo1'];
        $jelszo2 = $_POST['jelszo2'];
        $ekod = $_POST['ekod'];
        if($ekod == $randomString && $jelszo1 == $jelszo2)
        {
            require("kapcs.inc.php");
            $require = "UPDATE vevo SET jelszo='md5($randomString)' WHERE nev='$nev3'";
            msqli_query($con,$require);
        }
        else
        {
            print("Nem egyforma a két jelszó!/Nem jó az ellenörző kód, add meg újra!");
        }
     }
?>
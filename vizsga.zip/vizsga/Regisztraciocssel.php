<?php
              session_start();
              error_reporting(E_ERROR | E_PARSE);
              if(!isset($_POST['gomb'])){
              ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">

    
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
<section class="vh-100" style="background-color: #eee;">
  <div class="container h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-lg-12 col-xl-11">
        <div class="card text-black" style="border-radius: 25px;">
          <div class="card-body p-md-5">
            <div class="row justify-content-center">
              <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">


                <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Regisztráció</p>
                <?php print("<form action='regisztraciocssel.php' method='post'>"); ?>
                <form class="mx-1 mx-md-4">

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="text" name='nev' id="form3Example1c" class="form-control" />
                      <label class="form-label" for="form3Example1c">Felhasz</label>
                    </div>
                  </div>

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="email" name='email' id="form3Example3c" class="form-control" />
                      <label class="form-label" for="form3Example3c">Email</label>
                    </div>
                  </div>

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="password" name='jelszo' id="form3Example4c" class="form-control" />
                      <label class="form-label" for="form3Example4c">Jelszó</label>
                    </div>
                  </div>

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-key fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="password" name='jelszo2' id="form3Example4cd" class="form-control" />
                      <label class="form-label" for="form3Example4cd">Jelszó ismét</label>
                    </div>
                  </div>
                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-key fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="text" name='emlek2' id="form3Example4cd" class="form-control" />
                      <label class="form-label" for="form3Example4cd">emlék</label>
                    </div>
                  </div>
                  
                  <div class="form-check d-flex justify-content-center mb-5">
                    <input
                      class="form-check-input me-2"
                      type="checkbox"
                      name="agree"
                      value=""
                      id="form2Example3c"
                    />
                    <label class="form-check-label" for="form2Example3">
                      I agree all statements in <a href="#!">Terms of service</a>
                    </label>
                  </div>

                  <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                    <button type="submit"  name='gomb' class="btn btn-primary btn-lg">Regisztráció</button>
                  </div>
                  </form>
                </form>


              </div>
              <div class="col-md-10 col-lg-6 col-xl-7 d-flex align-items-center order-1 order-lg-2">

                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/draw1.webp" class="img-fluid" alt="Sample image">

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


    

    

<?php

}else{
  if (!isset($_POST['agree'])) {
    print("<script>alert('Fogadd el!'); window.location.href = 'regisztraciocssel.php';</script>");
  }else{
    require("kapcs.inc.php");
    
    $nev = $_POST['nev'];
    $email = $_POST['email'];
    $jelszo = md5($_POST['jelszo']);
    $jelszo2 = md5($_POST['jelszo2']);
    $emlek = $_POST['emlek2'];

    



    
    

    if($nev == NULL || $email == NULL || $jelszo == NULL )
    {
        print("<script>alert('Üres mező!'); window.location.href = 'regisztraciocssel.php';</script>");
    }
    elseif($jelszo != $jelszo2)
    {
        print("<script>alert('A jelszavak nem egyeznek!'); window.location.href = 'regisztraciocssel.php';</script>");
    }
    else
    {

        $sql = "SELECT * FROM vevo WHERE email='$email' LIMIT 1";
        $result = mysqli_query($con, $sql);
        $felhasznalo = mysqli_fetch_assoc($result);
        if($felhasznalo){
            if($felhasznalo['email'] === $email )
            {
                print("<script>alert('Ezzel az email címmel már regisztráltak!'); window.location.href = 'regisztraciocssel.php';</script>");
                
            }

            
        
        }
        $sql = "SELECT * FROM vevo WHERE nev='$nev' LIMIT 1";
        $result = mysqli_query($con, $sql);
        $felhasznalo = mysqli_fetch_assoc($result);
        if($felhasznalo){
            if($felhasznalo['nev'] === $nev )
            {
                print("<script>alert('Ilyen néven már regisztráltak!'); window.location.href = 'regisztraciocssel.php';</script>");
                
            }

            
        
        }
        else
        {
                echo $emlek;
                $query = "INSERT INTO vevo (nev, email, jelszo, emlek) VALUES ('$nev','$email','$jelszo','$emlek')";
                mysqli_query($con,$query) or die ('Hiba az adatbevitelnél!');
                print("Sikeres regisztráció!");
                require("kuldo.php");

                print("<script>window.location.href = 'Bejelentkezescssel.php';</script>");
        }
    }
 
  }
}   
    

?>

<script src="js/bootstrap.min.js"></script>
  <script src="js/popper.min.js"></script>

</body>
</html>
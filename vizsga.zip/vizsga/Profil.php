<?php
require("Register.php");

?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body> 
    <?php if(!isset($_POST['gomb'])){
        print("<form action='Profil.php' method='post'>");
        print('    <br> Add meg a születési dátumod:<br> <input type="date" id="start" name="datum"
        value="-"
        min="1931-12-31" max="2003-12-31"><br>');
        print("<p></p><label>Teljes neved: </label>");
        print("<input type='text' id='nev' name='tnev'><br>");
        print("<label>Lakcím: </label>");
        print("<input type='text' id='lakcim' name='lakcim'><br>");

        print("<br><input type='submit' value='save' name='gomb'><br>");
        print("</form>");


      
        $query2 = "SELECT * FROM vevo WHERE nev='".$_SESSION['nev2']."';";
        $result = $con->query($query2);
        if($result->num_rows>0){

        
        while($row = $result->fetch_assoc()){
            echo $row["ev"]."<br>".$row["tnev"]."<br>".$row["lakcim"];
            }
        } else{
            echo"Üres az adatbázis.";
        }
    }
    else
    {
        require("kapcs.inc.php");
        $datum = $_POST['datum'];
        $tnev = $_POST['tnev'];
        $lakcim = $_POST['lakcim'];
        $query = "UPDATE vevo SET ev='$datum', tnev='$tnev', lakcim='$lakcim' WHERE nev='".$_SESSION['nev2']."';";
        mysqli_query($con,$query) or die ('Hiba az adatbevitelnél!');
        print("<script>alert('Adatlap elmentve!'); window.location.href = 'Profil.php';</script>");

    } ?>
    
</body>
</html>
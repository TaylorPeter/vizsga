<?php
require("index.php");

?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body> 

    <?php if(!isset($_POST['gomb'])){
      $ev_="";
      $tnev_ = "";
      $lakcim_ = "";
      $profilkepek_ = "";
        $query2 = "SELECT * FROM vevo WHERE nev='".$_SESSION['nev']."';";
        $result = $con->query($query2);
        if($result->num_rows>0){

        
        while($row = $result->fetch_assoc()){
            $row["tnev"] == $_SESSION['nev'];
                $ev_ = $row["ev"];
                $tnev_ = $row["tnev"];
                $lakcim_ = $row["lakcim"];
                $profilkepek_ = $row["profilkepek"];
            
            //echo $row["ev"]."<br>".$row["tnev"]."<br>".$row["lakcim"]."<br><img height='100px' width='100px' src='".$row['profilkepek']."'>";

          }

        } else{
            echo"Üres az adatbázis.";
        }
        require("kapcs.inc.php");
        print("<form action='Profil.php' method='post' enctype='multipart/form-data'>");
        print("<br> Add meg a születési dátumod:<br> <input type='date' id='start' name='datum' value='$ev_'><br>");
        print("<p></p><label>Teljes neved: </label>");
        print("<input type='text' id='nev' value='$tnev_' name='tnev'><br>");
        print("<label>Lakcím: </label>");
        print("<input type='text' id='lakcim' value='$lakcim_' name='lakcim'><br>");
        print("<input type='file' id='profilkepek' name='profilkepek'><span name='old' value='=$profilkepek_'><br>");
        print("<br><input type='submit' value='Mentés' name='gomb'><br>");
        print("</form>");
        
    }
    else
    {
        require("kapcs.inc.php");
        $datum = $_POST['datum'];
        $tnev = $_POST['tnev'];
        $lakcim = $_POST['lakcim'];

        $target_dir = "profilkepek/";
        $target_file = $target_dir . basename($_FILES["profilkepek"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        
        // Check if image file is a actual image or fake image

        if(isset($_POST["gomb"])) {
          if(getimagesize($_FILES["profilkepek"]["tmp_name"]) == NULL){
            $query = "UPDATE vevo SET ev='$datum', tnev='$tnev', lakcim='$lakcim' WHERE nev='".$_SESSION['nev']."';";
            mysqli_query($con,$query) or die ('Hiba az adatbevitelnél!');
            print("<script>alert('Adatlap elmentve!'); window.location.href = 'Profil.php';</script>");
          }
          $check = getimagesize($_FILES["profilkepek"]["tmp_name"]);
          if($check !== false) {
            echo "A fálj egy kép - " . $check["mime"] . ".";
            $uploadOk = 1;
          } else {
            echo "A fálj nem kép";
            $uploadOk = 0;
          }
        }
        

        
        // Check file size
        if ($_FILES["profilkepek"]["size"] > 5000000) {
          echo "A fálj túl nagy.";
          $uploadOk = 0;
        }
        
        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
          echo "Csak JPG, JPEG, PNG kép tipusok elérhetőek.";
          $uploadOk = 0;
        }
        
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
          echo "A fáljt nem lehet feltölteni.";
        // if everything is ok, try to upload file
        } else {
          if (move_uploaded_file($_FILES["profilkepek"]["tmp_name"], $target_file)) {
            $profilkepek = "profilkepek/".$_FILES["profilkepek"]["name"];
            $query = "UPDATE vevo SET ev='$datum', tnev='$tnev', lakcim='$lakcim', profilkepek='$profilkepek' WHERE nev='".$_SESSION['nev']."';";
            mysqli_query($con,$query) or die ('Hiba az adatbevitelnél!');
            print("<script>alert('Adatlap elmentve!'); window.location.href = 'Profil.php';</script>");
            echo "A fájl ". htmlspecialchars( basename( $_FILES["profilkepek"]["name"])). " sikeresen fel lett töltve.";
          } else {
            print("<script>alert('Hiab az adatbevitelkor!'); window.location.href = 'Profil.php';</script>");
          }
        }

        
        


    } 

    
    ?>
    
</body>
</html>
<?php
session_start();
if(!isset($_POST['gomb'])){?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">

    
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
<section class="vh-100" style="background-color: #eee;">
  <div class="container h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-lg-12 col-xl-11">
        <div class="card text-black" style="border-radius: 25px;">
          <div class="card-body p-md-5">
            <div class="row justify-content-center">
              <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">


                <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Bejelentkezés</p>
                <?php print("<form action='Bejelentkezescssel.php' method='post'>"); ?>
                <form class="mx-1 mx-md-4">

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="text" name='nev' id="form3Example1c" class="form-control" />
                      <label class="form-label" for="form3Example1c">Felhasználónév</label>
                    </div>
                  </div>


                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="password" name='jelszo' id="form3Example1c" class="form-control" />
                      <label class="form-label" for="form3Example1c">Jelszó</label>
                      </div>
                  </div>


                  <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                    <button type="submit"  name='gomb' class="btn btn-primary btn-lg">Bejelentkezés</button>
                  </div>
                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                    <label class="form-label" for="form3Example3">
                    <a href='#' onclick='Btn()' name='gomb'>Jelszó emlékeztető</a><br>
                      <a href='#' onclick='Btn2()' name='gomb2'>Jelszó módosítás</a><br>
                      <p id='emlekezteto'><br>
                      <p id='modosit'><br>
                    </label>
                      </div>
                  </form>
                </form>


              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</body>
</html>
    <script>
    
    function Btn(){
        
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                document.getElementById("emlekezteto").innerHTML = this.responseText;
            }
            document.getElementById("emlekezteto").innerHTML = this.responseText;
            window.location.reload();
            
        };
        if(document.getElementById("nev").value == ""){
            alert("Töltsd ki a név mezőt!");

        }
        else
        {
        var nev2 = document.getElementById("nev").value;
        xmlhttp.open("GET", "emlekezteto.php?q="+nev2, true);
        xmlhttp.send();
        }
    }
    </script>

    <script>
    
    function Btn2(){
        
        var xmlhttp2 = new XMLHttpRequest();
        xmlhttp2.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                document.getElementById("modosit").innerHTML = this.responseText;
                print("Elküldtük emailben!");
            }
            document.getElementById("modosit").innerHTML = this.responseText;
            window.location.reload();
            
        };
        if(document.getElementById("nev").value == ""){
            alert("Töltsd ki a név mezőt!");

        }
        else
        {
        var nev2 = document.getElementById("nev").value;
        xmlhttp2.open("GET", "jelszomodositas.php?q="+nev2, true);
        xmlhttp2.send();
        }
    }
    </script>
<?php


    
}
else{

    require("kapcs.inc.php");

    $nev = $_POST['nev'];
    
    $jelszo = $_POST['jelszo'];
    
    $jelszo = md5($jelszo);

    $query = "SELECT * FROM vevo  WHERE nev='$nev' AND jelszo='$jelszo'";
    //$query2 = "SELECT * FROM vevoid WHERE nev='$nev' AND jelszo='$jelszo'";
    $results = mysqli_query($con, $query);
    //$results2 = mysqli_query($con, $query2);

    while($rekord=mysqli_fetch_object($results))
    {
        if ($rekord->nev == $nev && $rekord->jelszo == $jelszo){
        $vevoid = $rekord->vevoid;
        $_SESSION['vevoid'] = $vevoid;
        //print($vevoid);
        }
    }
    if(mysqli_num_rows($results) > 0)
    {
        $_SESSION['nev'] = $nev;
        $_SESSION['vevoid'] = $vevoid;
        
        print("<script>alert('Sikeres Belépés'); window.location.href = 'index.php';</script>");

    }
    else
    {
        print("<script>alert('Sikeres Belépés'); window.location.href = 'Bejelentkezescssel.php';</script>");
    }
}

?>
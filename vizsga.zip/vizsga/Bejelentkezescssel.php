<?php
session_start();
if(!isset($_POST['gomb'])){?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">

    
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
<section class="vh-100" style="background-color: #eee;">
  <div class="container h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-lg-12 col-xl-11">
        <div class="card text-black" style="border-radius: 25px;">
          <div class="card-body p-md-5">
            <div class="row justify-content-center">
              <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">


                <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Bejelentkezés</p>
                <?php print("<form action='Bejelentkezescssel.php' method='post'>"); ?>
                <form class="mx-1 mx-md-4">

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="text" name='nev' id="form3Example1c" class="form-control" />
                      <label class="form-label" for="form3Example1c">Felhasz</label>
                    </div>
                  </div>


                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                   
                      <input type="password" name='jelszo' id="form3Example4c" class="form-control" /><br>
                      <label class="form-label" for="form3Example4c">Jelszó</label>
                    
                  </div>
                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                    
                      
                      <label class="form-label" for="form3Example4c">Jelszó</label>
                    
                  </div>


                  <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                    <button type="submit"  name='gomb' class="btn btn-primary btn-lg">Bejelntkezés</button>
                  </div>
                  </form>
                </form>


              </div>
              <div class="col-md-10 col-lg-6 col-xl-7 d-flex align-items-center order-1 order-lg-2">

                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/draw1.webp" class="img-fluid" alt="Sample image">

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php


    print("</form>");
}
else{

    require("kapcs.inc.php");

    $nev = $_POST['nev'];
    
    $jelszo = $_POST['jelszo'];
    
    $jelszo = md5($jelszo);

    $query = "SELECT * FROM vevo  WHERE nev='$nev' AND jelszo='$jelszo'";
    //$query2 = "SELECT * FROM vevoid WHERE nev='$nev' AND jelszo='$jelszo'";
    $results = mysqli_query($con, $query);
    //$results2 = mysqli_query($con, $query2);

    while($rekord=mysqli_fetch_object($results))
    {
        if ($rekord->nev == $nev && $rekord->jelszo == $jelszo){
        $vevoid = $rekord->vevoid;
        $_SESSION['vevoid'] = $vevoid;
        //print($vevoid);
        }
    }
    if(mysqli_num_rows($results) > 0)
    {
        $_SESSION['nev'] = $nev;
        $_SESSION['vevoid'] = $vevoid;
        
        print("<script>alert('Sikeres Belépés'); window.location.href = 'index.php';</script>");

    }
    else
    {
        print("<script>alert('Sikeres Belépés'); window.location.href = 'Bejelentkezescssel.php';</script>");
    }
}

?>
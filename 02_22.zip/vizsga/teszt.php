<link rel="stylesheet" href="VizsgaCSS.css">
<?php
session_start();

require("kapcs.inc.php");

$jatek = mysqli_query($con,"SELECT * FROM termek") or die ("Nem sikerült a lekérdezés!");

$rekord = mysqli_fetch_object($jatek);

print("<div class='jatek'><img src='".$rekord->kep."' height='200px' width='200px'><br>".$rekord->nev."<br>".$rekord->ar."<br><input type='button' name='".$rekord->nev."' value='Kosárba'></div>");

?>
<script>
    $("'#".$rekord->nev."'").on('click', function(){
        
    }
        
</script>
<?php

?>